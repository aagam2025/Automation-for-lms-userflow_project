/* Tin Can configuration */

//
// ActivityID that is sent for the statement's object
//
TC_COURSE_ID = "http://hFLLmR8Yn2RdE4SccTq8O6u3feAHDeyM_rise"

//
// CourseName for the activity
//
TC_COURSE_NAME = {
  "en-US": "Food Manager Training 2.2 - Minified - 03"
};

//
// CourseDesc for the activity
//
TC_COURSE_DESC = {
  "en-US": "&lt;p style=&#34;text-align: justify&#34;&gt;&lt;strong&gt;Purpose of Food Manager Training&lt;/strong&gt;&lt;p style=&#34;text-align: justify&#34;&gt;The Food Manager Training program provides the knowledge and skills to ensure food safety and protect public health in food service environments. By the end of this course, learners will be able to:&lt;strong&gt;&lt;br class=&#34;break-when-trailing&#34;&gt;Understand Food Safety Principles&lt;/strong&gt;&lt;ul&gt;&lt;li&gt;Recognize the importance of food safety for both public health and business success.&lt;/li&gt;&lt;li&gt;Identify and manage time and temperature control for safety (TCS) foods by storing, cooking, cooling, and holding them at safe temperatures.&lt;/li&gt;&lt;li&gt;Control time and temperature to prevent bacterial growth.&lt;/li&gt;&lt;li&gt;Detect and respond to biological, chemical, and physical contamination risks.&lt;/li&gt;&lt;/ul&gt;&lt;strong&gt;Manage Staff and Operations&lt;/strong&gt;&lt;ul&gt;&lt;li&gt;Ensure staff compliance with hygiene standards and illness reporting protocols.&lt;/li&gt;&lt;li&gt;Manage the safe flow of food from receiving to serving, including self-service and off-site scenarios.&lt;/li&gt;&lt;li&gt;Apply effective cleaning, sanitizing, and facility maintenance practices.&lt;/li&gt;&lt;/ul&gt;&lt;strong&gt;Implement Systems and Procedures&lt;/strong&gt;&lt;ul&gt;&lt;li&gt;Implement a Food Safety Management System (FSMS) using HACCP principles to monitor and control food safety risks.&lt;/li&gt;&lt;li&gt;Manage receiving, storage, and inventory using FIFO and the A.L.E.R.T. framework.&lt;/li&gt;&lt;li&gt;Prevent pest contamination and maintain accurate documentation.&lt;/li&gt;&lt;li&gt;Utilize food safety tools such as thermometers, logs, and traceability systems to support safe operations.&lt;/li&gt;&lt;/ul&gt;"
};
